package com.segundatela.app

import android.os.Handler
import android.os.HandlerThread
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Envia eventos de entrada (mouse/teclado) do tablet para o servidor do PC.
 *
 * Mantém um socket keep-alive separado do stream de vídeo e manda uma linha de
 * texto por evento (POST /input), com TCP_NODELAY para latência baixa. As
 * coordenadas são normalizadas (0..1) em relação à IMAGEM exibida; o servidor
 * converte para a área do monitor que está transmitindo.
 */
class InputSender(
    private val host: String,
    private val port: Int,
    private val pin: String
) {
    private val fila = ConcurrentLinkedQueue<String>()
    @Volatile private var ativo = false
    private var th: HandlerThread? = null
    private var handler: Handler? = null
    private var socket: Socket? = null
    private var out: OutputStream? = null

    fun start() {
        if (ativo) return
        ativo = true
        th = HandlerThread("input").also { it.start() }
        handler = Handler(th!!.looper)
        handler?.post { conectar() }
    }

    fun stop() {
        ativo = false
        handler?.post {
            try { socket?.close() } catch (_: Exception) {}
        }
        th?.quitSafely()
        th = null; handler = null
    }

    private fun conectar() {
        if (!ativo) return
        try {
            val s = Socket().apply {
                tcpNoDelay = true
                connect(InetSocketAddress(host, port), 4000)
            }
            val o = s.getOutputStream()
            val req = "POST /input HTTP/1.1\r\nHost: $host\r\n" +
                "Content-Type: text/plain\r\nConnection: keep-alive\r\n" +
                "X-Stream: input\r\n\r\n"
            o.write(req.toByteArray(Charsets.ISO_8859_1)); o.flush()
            socket = s; out = o
        } catch (_: Exception) {
            if (ativo) handler?.postDelayed({ conectar() }, 1000)
        }
    }

    // ---- API de eventos (coordenadas normalizadas 0..1) ----
    fun move(x: Float, y: Float) = enfileira("m ${f(x)} ${f(y)}")
    fun down(x: Float, y: Float) = enfileira("d ${f(x)} ${f(y)}")
    fun up(x: Float, y: Float) = enfileira("u ${f(x)} ${f(y)}")
    fun rightClick(x: Float, y: Float) = enfileira("r ${f(x)} ${f(y)}")
    fun scroll(x: Float, y: Float, dy: Int) = enfileira("s ${f(x)} ${f(y)} $dy")
    fun key(code: String) = enfileira("k $code")
    fun text(t: String) = enfileira("t " + t.replace("\n", "\\n"))

    private fun f(v: Float) = String.format(java.util.Locale.US, "%.4f", v.coerceIn(0f, 1f))

    private fun enfileira(linha: String) {
        if (!ativo) return
        val l = if (pin.isNotEmpty()) "$linha|$pin\n" else "$linha\n"
        handler?.post { envia(l) }
    }

    private fun envia(linha: String) {
        val o = out ?: run { conectar(); return }
        try {
            o.write(linha.toByteArray(Charsets.UTF_8)); o.flush()
        } catch (_: Exception) {
            try { socket?.close() } catch (_: Exception) {}
            out = null; socket = null
            if (ativo) conectar()
        }
    }
}
