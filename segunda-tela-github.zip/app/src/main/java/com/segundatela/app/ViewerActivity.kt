package com.segundatela.app

import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import com.segundatela.app.databinding.ActivityViewerBinding
import kotlin.math.abs

class ViewerActivity : AppCompatActivity(), MjpegView.Listener {

    private lateinit var b: ActivityViewerBinding
    private val ui = Handler(Looper.getMainLooper())
    private val hideStatus = Runnable { b.status.visibility = View.GONE }

    private var input: InputSender? = null
    private var controlEnabled = false

    // --- Estado dos gestos ---
    private var downX = 0f; private var downY = 0f
    private var downTime = 0L
    private var moved = false
    private var dragging = false
    private var multi = false
    private var multiMoved = false
    private var lastAvgY = 0f
    private val slop by lazy { resources.displayMetrics.density * 10 }
    private val longPress = Runnable {
        if (!multi && !moved) {
            mapSend(downX, downY) { x, y -> input?.down(x, y) }
            dragging = true
            b.root.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        }
    }

    private var selfEdit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        b = ActivityViewerBinding.inflate(layoutInflater)
        setContentView(b.root)

        val url = intent.getStringExtra("url") ?: run { finish(); return }
        if (intent.getBooleanExtra("lockLandscape", false)) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }

        controlEnabled = intent.getBooleanExtra("control", false)
        if (controlEnabled) {
            val host = intent.getStringExtra("host") ?: ""
            val port = intent.getIntExtra("port", 8080)
            val pin = intent.getStringExtra("pin") ?: ""
            input = InputSender(host, port, pin).also { it.start() }
            b.mjpeg.setOnTouchListener { _, e -> onTouch(e); true }
        }

        setupMenu()
        b.mjpeg.listener = this
        b.status.text = getString(R.string.connecting)
        b.mjpeg.start(url)
    }

    // ---- Menu de configurações ----
    private fun setupMenu() {
        b.btnSettings.setOnClickListener { openMenu(true) }
        b.scrim.setOnClickListener { openMenu(false) }
        b.btnDisconnect.setOnClickListener { finish() }

        // Seção de teclado só faz sentido com controle ligado.
        val visKb = if (controlEnabled) View.VISIBLE else View.GONE
        b.lblKeyboardSection.visibility = visKb
        b.btnKeyboard.visibility = visKb
        b.keysRow.visibility = visKb
        b.lblGestures.visibility = visKb

        if (controlEnabled) {
            b.btnKeyboard.setOnClickListener { toggleKeyboard() }
            b.keyEsc.setOnClickListener { input?.key("ESC") }
            b.keyTab.setOnClickListener { input?.key("TAB") }
            b.keyWin.setOnClickListener { input?.key("WIN") }
            b.keyCtrlC.setOnClickListener { input?.key("CTRL+C") }
            b.keyCtrlV.setOnClickListener { input?.key("CTRL+V") }
            b.keyAltTab.setOnClickListener { input?.key("ALT+TAB") }
            b.keyLeft.setOnClickListener { input?.key("LEFT") }
            b.keyRight.setOnClickListener { input?.key("RIGHT") }
            b.keyUp.setOnClickListener { input?.key("UP") }
            b.keyDown.setOnClickListener { input?.key("DOWN") }
            b.keyEnter.setOnClickListener { input?.key("ENTER") }

            b.hiddenInput.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (selfEdit || s == null) return
                    val txt = s.toString()
                    if (txt.isNotEmpty()) {
                        input?.text(txt)
                        selfEdit = true; s.clear(); selfEdit = false
                    }
                }
            })
            b.hiddenInput.setOnKeyListener { _, code, ev ->
                if (ev.action == KeyEvent.ACTION_DOWN && code == KeyEvent.KEYCODE_DEL) {
                    input?.key("BACKSPACE"); true
                } else false
            }
        }
    }

    private fun openMenu(open: Boolean) {
        b.settingsPanel.visibility = if (open) View.VISIBLE else View.GONE
        b.scrim.visibility = if (open) View.VISIBLE else View.GONE
        if (open) {
            b.status.visibility = View.GONE
            ui.removeCallbacks(hideStatus)
        } else {
            enterImmersive()
        }
    }

    private fun menuAberto() = b.settingsPanel.visibility == View.VISIBLE

    override fun onBackPressed() {
        if (menuAberto()) openMenu(false) else super.onBackPressed()
    }

    // ---- Gestos de toque (controle do PC) ----
    private fun onTouch(e: MotionEvent) {
        if (menuAberto()) return
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multi = false; multiMoved = false; moved = false; dragging = false
                downX = e.x; downY = e.y; downTime = System.currentTimeMillis()
                mapSend(e.x, e.y) { x, y -> input?.move(x, y) }
                ui.postDelayed(longPress, 500)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                multi = true
                ui.removeCallbacks(longPress)
                lastAvgY = avgY(e)
            }
            MotionEvent.ACTION_MOVE -> {
                if (multi) {
                    val ay = avgY(e)
                    val dy = ay - lastAvgY
                    if (abs(dy) > slop * 0.6f) {
                        val ticks = (-dy / slop).toInt()
                        if (ticks != 0) {
                            mapSend(e.x, e.y) { x, y -> input?.scroll(x, y, ticks) }
                            lastAvgY = ay; multiMoved = true
                        }
                    }
                } else {
                    mapSend(e.x, e.y) { x, y -> input?.move(x, y) }
                    if (!moved && (abs(e.x - downX) > slop || abs(e.y - downY) > slop)) {
                        moved = true
                        if (!dragging) ui.removeCallbacks(longPress)
                    }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (multi && !multiMoved) {
                    mapSend(downX, downY) { x, y -> input?.rightClick(x, y) }
                    multiMoved = true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                ui.removeCallbacks(longPress)
                if (!multi) {
                    if (dragging) {
                        mapSend(e.x, e.y) { x, y -> input?.up(x, y) }
                    } else if (!moved && System.currentTimeMillis() - downTime < 400) {
                        mapSend(downX, downY) { x, y -> input?.down(x, y); input?.up(x, y) }
                    }
                }
                multi = false; dragging = false; moved = false
            }
        }
    }

    private fun avgY(e: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until e.pointerCount) sum += e.getY(i)
        return sum / e.pointerCount
    }

    private inline fun mapSend(px: Float, py: Float, send: (Float, Float) -> Unit) {
        val p = b.mjpeg.toImage(px, py) ?: return
        send(p.first, p.second)
    }

    private fun toggleKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        b.hiddenInput.requestFocus()
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
    }

    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    override fun onConnected() {
        b.status.text = getString(R.string.connected)
        ui.removeCallbacks(hideStatus)
        ui.postDelayed(hideStatus, 1500)
    }

    override fun onDisconnected(reason: String) {
        if (!menuAberto()) b.status.visibility = View.VISIBLE
        ui.removeCallbacks(hideStatus)
        b.status.text = getString(R.string.reconnecting, reason)
    }

    override fun onStats(fps: Double) {
        if (b.status.visibility == View.VISIBLE && b.status.text.toString().startsWith("•")) {
            b.status.text = String.format("• %s — %.0f fps", getString(R.string.connected), fps)
        }
    }

    override fun onDestroy() {
        b.mjpeg.stop()
        input?.stop()
        super.onDestroy()
    }
}
