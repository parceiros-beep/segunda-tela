package com.segundatela.app

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.segundatela.app.databinding.ActivityViewerBinding

class ViewerActivity : AppCompatActivity(), MjpegView.Listener {

    private lateinit var b: ActivityViewerBinding
    private val ui = Handler(Looper.getMainLooper())
    private val hideStatus = Runnable { b.status.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // Usa a tela toda, inclusive sob o recorte (notch) em tablets/celulares.
        window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        b = ActivityViewerBinding.inflate(layoutInflater)
        setContentView(b.root)

        val url = intent.getStringExtra("url") ?: run { finish(); return }
        if (intent.getBooleanExtra("lockLandscape", false)) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        b.mjpeg.listener = this
        b.status.text = getString(R.string.connecting)

        // Tap toggles the info bar; back button exits.
        b.root.setOnClickListener { toggleStatus() }

        b.mjpeg.start(url)
    }

    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    private fun toggleStatus() {
        if (b.status.visibility == View.VISIBLE) {
            ui.removeCallbacks(hideStatus)
            b.status.visibility = View.GONE
        } else {
            b.status.visibility = View.VISIBLE
            ui.removeCallbacks(hideStatus)
            ui.postDelayed(hideStatus, 2500)
        }
    }

    override fun onConnected() {
        b.status.text = getString(R.string.connected)
        ui.removeCallbacks(hideStatus)
        ui.postDelayed(hideStatus, 1500)
    }

    override fun onDisconnected(reason: String) {
        b.status.visibility = View.VISIBLE
        ui.removeCallbacks(hideStatus)
        b.status.text = getString(R.string.reconnecting, reason)
    }

    override fun onStats(fps: Double) {
        if (b.status.visibility == View.VISIBLE && b.status.text.toString().startsWith("•")) {
            b.status.text = String.format("• %s — %.0f fps", getString(R.string.connected), fps)
        }
    }

    override fun onDestroy() {
        b.mjpeg.stop()
        super.onDestroy()
    }
}
