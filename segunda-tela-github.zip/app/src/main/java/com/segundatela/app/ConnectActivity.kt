package com.segundatela.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.chip.Chip
import com.segundatela.app.databinding.ActivityConnectBinding

class ConnectActivity : AppCompatActivity(), NsdDiscovery.Listener {

    private lateinit var b: ActivityConnectBinding
    private val prefs by lazy { getSharedPreferences("segundatela", Context.MODE_PRIVATE) }
    private var discovery: NsdDiscovery? = null
    private val seen = HashSet<String>()

    // Bitrate em Mbps; -1 = Auto (otimizar pela rede); 0 = qualidade fixa
    private val bitrateValues = listOf(-1, 0, 5, 10, 15, 20, 25, 30, 40)
    private val fpsValues = listOf(10, 15, 20, 24, 30, 45, 60)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityConnectBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.editHost.setText(prefs.getString("host", ""))
        b.editPort.setText(prefs.getString("port", "8080"))
        b.editPin.setText(prefs.getString("pin", ""))
        b.editMonitor.setText(prefs.getInt("monitor", 1).toString())
        b.seekQuality.progress = prefs.getInt("quality", 70).coerceIn(10, 95)
        b.seekScale.progress = prefs.getInt("scale", 100).coerceIn(20, 100)
        b.chkOrientation.isChecked = prefs.getBoolean("lockLandscape", false)
        b.chkAutoconnect.isChecked = prefs.getBoolean("autoconnect", false)
        b.chkControl.isChecked = prefs.getBoolean("control", true)
        b.chkExtend.isChecked = prefs.getBoolean("extend", false)

        setupSpinners()
        setupSliders()
        buildRecentChips()

        b.btnAdvanced.setOnClickListener {
            b.advanced.visibility =
                if (b.advanced.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        b.btnUsb.setOnClickListener {
            b.editHost.setText("127.0.0.1")
            Toast.makeText(this,
                "Modo USB: rode 'adb reverse tcp:8080 tcp:8080' no PC. Veja o LEIA-ME.",
                Toast.LENGTH_LONG).show()
        }
        b.btnConnect.setOnClickListener { doConnect() }

        if (b.chkAutoconnect.isChecked && !b.editHost.text.isNullOrBlank()) {
            b.root.post { doConnect() }
        }
    }

    private fun setupSpinners() {
        val brLabels = bitrateValues.map {
            when (it) {
                -1 -> getString(R.string.auto_optimize)
                0 -> getString(R.string.quality_fixed)
                else -> "$it Mbps"
            }
        }
        b.spinnerBitrate.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, brLabels)
        b.spinnerBitrate.setSelection(
            bitrateValues.indexOf(prefs.getInt("bitrate", -1)).coerceAtLeast(0))

        b.spinnerFps.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            fpsValues.map { "$it fps" })
        b.spinnerFps.setSelection(
            fpsValues.indexOf(prefs.getInt("fps", 20)).coerceAtLeast(0))
    }

    private fun setupSliders() {
        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = refreshLabels()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }
        b.seekQuality.setOnSeekBarChangeListener(listener)
        b.seekScale.setOnSeekBarChangeListener(listener)
        refreshLabels()
    }

    private fun refreshLabels() {
        b.lblQuality.text = getString(R.string.quality_label, b.seekQuality.progress.coerceAtLeast(10))
        b.lblScale.text = getString(R.string.scale_label, b.seekScale.progress.coerceAtLeast(20))
    }

    // ---- Recentes ----
    private fun buildRecentChips() {
        b.chipRecent.removeAllViews()
        val recents = prefs.getString("recents", "")!!.split("|").filter { it.isNotBlank() }
        for (host in recents.take(6)) {
            b.chipRecent.addView(Chip(this).apply {
                text = host
                isCheckable = false
                setOnClickListener { b.editHost.setText(host) }
            })
        }
    }

    private fun saveRecent(host: String) {
        val cur = prefs.getString("recents", "")!!.split("|").filter { it.isNotBlank() }
        val updated = (listOf(host) + cur.filter { it != host }).take(6)
        prefs.edit().putString("recents", updated.joinToString("|")).apply()
    }

    // ---- Descoberta mDNS ----
    override fun onStart() {
        super.onStart()
        seen.clear()
        b.chipDiscovered.removeAllViews()
        b.lblSearching.visibility = View.VISIBLE
        discovery = NsdDiscovery(this).also { it.listener = this; it.start() }
    }

    override fun onStop() {
        super.onStop()
        discovery?.stop()
        discovery = null
    }

    override fun onFound(device: NsdDiscovery.Device) {
        val key = "${device.host}:${device.port}"
        if (!seen.add(key)) return
        b.lblSearching.visibility = View.GONE
        b.chipDiscovered.addView(Chip(this).apply {
            text = "${device.name} (${device.host})"
            isCheckable = false
            setOnClickListener {
                b.editHost.setText(device.host)
                b.editPort.setText(device.port.toString())
            }
        })
    }

    // ---- Conectar ----
    private fun doConnect() {
        val host = b.editHost.text.toString().trim()
        val port = b.editPort.text.toString().trim().ifEmpty { "8080" }
        if (host.isEmpty()) {
            Toast.makeText(this, getString(R.string.err_host), Toast.LENGTH_SHORT).show()
            return
        }
        val rawBitrate = bitrateValues[b.spinnerBitrate.selectedItemPosition]
        var bitrate = rawBitrate
        var fps = fpsValues[b.spinnerFps.selectedItemPosition]
        if (bitrate == -1) {  // Auto: otimizar pela rede detectada
            val st = NetInfo.read(this)
            bitrate = st.suggestedBitrate
            fps = st.suggestedFps
            Toast.makeText(this,
                "Auto: ${NetInfo.describe(st)} → ${bitrate} Mbps / ${fps} fps",
                Toast.LENGTH_SHORT).show()
        }
        val quality = b.seekQuality.progress.coerceIn(10, 95)
        val scalePct = b.seekScale.progress.coerceIn(20, 100)
        val scale = scalePct / 100.0
        val monitor = b.editMonitor.text.toString().trim().toIntOrNull() ?: 1
        val pin = b.editPin.text.toString().trim()

        val extend = b.chkExtend.isChecked
        val control = b.chkControl.isChecked

        prefs.edit()
            .putString("host", host).putString("port", port).putString("pin", pin)
            .putInt("bitrate", rawBitrate).putInt("fps", fps)
            .putInt("quality", quality).putInt("scale", scalePct)
            .putInt("monitor", monitor)
            .putBoolean("lockLandscape", b.chkOrientation.isChecked)
            .putBoolean("autoconnect", b.chkAutoconnect.isChecked)
            .putBoolean("control", control)
            .putBoolean("extend", extend)
            .apply()
        saveRecent(host)

        val sb = StringBuilder("http://$host:$port/stream?fps=$fps&scale=$scale&monitor=$monitor")
        if (bitrate > 0) sb.append("&bitrate=$bitrate") else sb.append("&quality=$quality")
        if (extend) sb.append("&extend=1")
        if (pin.isNotEmpty()) sb.append("&pin=$pin")

        val portNum = port.toIntOrNull() ?: 8080
        startActivity(Intent(this, ViewerActivity::class.java)
            .putExtra("url", sb.toString())
            .putExtra("lockLandscape", b.chkOrientation.isChecked)
            .putExtra("control", control)
            .putExtra("host", host)
            .putExtra("port", portNum)
            .putExtra("pin", pin))
    }

    override fun onResume() {
        super.onResume()
        buildRecentChips()
        try {
            b.lblNet.text = NetInfo.describe(NetInfo.read(this))
        } catch (_: Exception) {}
    }
}
